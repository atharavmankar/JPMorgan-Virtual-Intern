# JPMorgan-Chase-Software-Engineering-Virtual-Internship

This repository contains the submitted patch files of the various tasks assigned by JPMorgan Chase &amp; Co. Software Engineering Virtual Internship.

## Website Link:

[https://www.insidesherpa.com/virtual-internships/R5iK7HMxJGBgaSbvk](https://www.insidesherpa.com/virtual-internships/R5iK7HMxJGBgaSbvk)

## My Certificate of Completion 

![image](https://user-images.githubusercontent.com/76099182/119376151-42d34800-bcd9-11eb-8d07-58b253435869.png)

## For any assistance/queries :

 ✉️ abhishek1643.cse18@chitkara.edu.in
